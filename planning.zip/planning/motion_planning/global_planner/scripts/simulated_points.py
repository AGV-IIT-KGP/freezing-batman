print 6
print "0,0"
print "20,10"
print "30,30"
print "40,30"
print "50,10"
print "60,0"
