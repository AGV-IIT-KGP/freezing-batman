#define IMU_COM_PORT "/dev/ttyUSB2"
#define IMU_BAUD_RATE 57600

#define BOT_COM_PORT "/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0"
#define BOT_BAUD_RATE 19200

#define ENCODER_COM_PORT "/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port1"
#define ENCODER_BAUD_RATE 19200

#define GPS_COM_PORT "/dev/ttyUSB0"
